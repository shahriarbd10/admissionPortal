export default function AdminHome() {
  return <div className="p-6">Admin Dashboard (protected)</div>;
}
