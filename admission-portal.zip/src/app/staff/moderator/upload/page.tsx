// src/app/staff/moderator/upload/page.tsx
export { default } from "../questions/page";
