export const departments = [
  { id: "cse", name: "Computer Science & Engineering" },
  { id: "eee", name: "Electrical & Electronic Engineering" },
  { id: "bba", name: "Business Administration" },
  { id: "eng", name: "English" },
];
